# campus-recruitment-system
this system are consist of student, company and admin login the project benificial for students, colleges and various companies for visiting the campus  for recruitment and even the college placement officer
